package de.uni.hd.isw.bigfolder;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

class TrainerTest {

    @Test
    void link() {
        Trainer Ash = new Trainer("Ash","Ketchup");
        Pokemon belongstoAsh = new Pokemon("Glurak",Type.FIRE);
        Trainer Red  = new Trainer("Red","Rival");
        Pokemon belongstoRed = new Pokemon("Dragonia",Type.WATER);
        Ash.Link(belongstoAsh);
        Red.Link(belongstoAsh);
        assertEquals(Pokemon.Map.get(belongstoAsh.ID),"Ash");
        System.out.println("Red konnte Ash sein Pokemon nicht klauen");
    }

    @Test
    void addPokemon() {
        int count=0;
        Stack<Pokemon> st = new Stack<Pokemon>();
        Trainer test = new Trainer("ISW","ROCKS");
        for(int i=0;i<100;i++){
            Pokemon t = new Pokemon("Stop_Creating_me",Type.FIRE);
            test.addPokemon(t);
            st.push(t);
            if(st.pop()==t){
                count++;
            }
        }
        assertEquals(100,count);
        System.out.println("Es sind genau soviele Pokemon in der Liste wie eingefügt,OK");
    }

    @Test
    void listPokemon() {
        Trainer test = new Trainer("ISW","ROCKS");
        Pokemon first = new Pokemon("Glurak",Type.FIRE);
        Pokemon sec   = new Pokemon("Shiggy",Type.WATER);
        List<Pokemon> LList = new ArrayList<>();

        LList.add(first);
        LList.add(sec);
        test.addPokemon(first);
        test.addPokemon(sec);
        test.ListPokemon();
        assertEquals(LList,test.pokemons);
        System.out.println("Gleiche ELemente in Liste wie in Persönliche Pokemon Liste,OK");
    }

    @Test
    void testListPokemon() {
    }

    @Test
    void testListPokemon1() {
    }
}