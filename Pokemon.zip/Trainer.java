package de.uni.hd.isw.bigfolder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Trainer  {

   final  private String name;
   final private String lastname;
    List<Pokemon> pokemons = new ArrayList<>(); //Dient als Liste aller Pokemon
    Trainer(String name,String lastname){
        this.name = name;
        this.lastname = lastname;
    }
    public String getname(){
        return this.name;
    }
     protected void Link(Pokemon Ball){
         /*if(!Pokemon.Map.containsKey(Ball.ID)){ //Ist nur für Testfälle reingeschreiben
        Pokemon.Map.put(Ball.ID,this);
        return;
         }
         System.out.println("Pokemon is not Linkable, it belongs to" + " " +Pokemon.Map.get(Ball.ID));
*/
         Ball.lk = this;
    }
   void addPokemon(Pokemon ball){
        if(this.name.equals(Pokemon.Map.get(ball.ID))){
            System.out.println("You dummy this is already yours");
            return;
        }
        if(!Pokemon.Map.containsKey(ball.ID)) {
            pokemons.add(ball);
            Link(ball);
            return;
        }
       System.out.printf("This Pokemon belongs to" +  " " + Pokemon.Map.get(ball.ID)); //durch unique ID kann Trainer leicht gefunden werden
   }
   void ListPokemon(){
        for(int i=0;i<pokemons.size();i++){ //Keine ID in Tabelle-> Pokemon ist noch "Wild"
            System.out.print(pokemons.get(i).toString());
            System.out.printf("\n");
        }
   }

   void ListPokemon(Type type){
        for(int i=0;i<pokemons.size();i++){
            if(type==pokemons.get(i).get_type()){
            System.out.println(pokemons.get(i).toString());
        }
   }
}
    void swap(Pokemon p1,Pokemon p2){
        System.out.println("Initialise swapping....");
        Pokemon temp = p1;

        int swap2=0;
        while(swap2<p2.lk.pokemons.size()){
            if(p2.lk.pokemons.get(swap2).ID==p2.ID){
                System.out.println("found");
                break;
            }
            System.out.println(swap2);
            swap2++;
        }
        int swap1=0;
        while(swap1<this.pokemons.size()){
            if(this.pokemons.get(swap1).ID == p1.ID){
                break;
            }
            swap1++;
        }
        this.pokemons.set(swap1,p2);
        p2.lk.pokemons.set(swap2,temp);
        System.out.println("Swapping was sucsefull");
        deleteLink(p1);
        deleteLink(p2);
        this.Link(p2);
        p2.lk.Link(p1);

    }
void ListPokemon(int i){
    System.out.println(pokemons.get(i).toString());
}
void deleteLink(Pokemon Ball){
       // Pokemon.Map.remove(Ball.ID);
        Ball.lk=null;
}
}
