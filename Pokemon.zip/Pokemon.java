package de.uni.hd.isw.bigfolder;

import java.util.HashMap;
import java.util.UUID;

public class Pokemon {
    protected static HashMap<Integer, Trainer> Map = new HashMap<Integer, Trainer>(); /*Pokemon als Key ->
    zwingt eindeutige Zuweisung zu gehörigen Trainer static da wir keine neue HashMap für jedes objekt
    erstellen wollen
    */
    public void copy(Pokemon p1){
        this._name = p1.get_name();
        this._type = p1.get_type();
        this.ID = p1.ID;
    }
    private String _name;
    Type _type;
    int ID;
    static int next; // static ermöglicht fortlaufendes zählen der ID
    Trainer lk;
    Pokemon(String name, Type type) {
        this._name = name;
        this._type = type;
        ID = next;
        next++;
        lk=null;
    }
    Pokemon(Pokemon p){
        this._name=p.get_name();
        this._type=get_type();
        this.ID = p.ID;
        this.lk = p.lk;
    }
    void afterswap(){
        next--;
    }
    public String get_name() {
        return this._name;
    }

    public Type get_type() {
        return this._type;
    }

    public void set_name(String _name) { //this zeigt dem Compiler das es sich um die Instanz des Objektes geht
        this._name = _name;
    }

    public void set_Type(Type _type) {
        this._type = _type;
    }

    public void setTrainer(Trainer t){
        this.lk = t;
    }
    public String toString() {
        return _name + " |  " + _type.toString() + " |  " + String.valueOf(ID);
    }


    public static void main(String[] args) {
        Pokemon first; // Deklariert
        first = new Pokemon("Glumanda", Type.FIRE);
        Pokemon sec = new Pokemon("Bisasam",Type.WATER);
        Trainer Ash = new Trainer("Ash","Ketchup");
        Ash.addPokemon(first);
        Trainer Red = new Trainer("Red","Rival");
        Red.addPokemon(sec);
        Swap swapper = new Swap(first,sec);
        swapper.execute();
        /*for(int i=0;i<5;i++){
            String random = UUID.randomUUID() .toString().substring(0,4);
            Pokemon te = new Pokemon(random,Type.WATER);
            Ash.addPokemon(te);

        }*/
        //Ash.ListPokemon(); //List every Pokemon which belongs to Ash
        //Red.ListPokemon();
        //Ash.ListPokemon(Type.WATER); //List every Pokemon which is Type Water
        //Ash.ListPokemon(0); //List first Pokemon in Ash's Bag
        //Red.ListPokemon();
       //Red.addPokemon(sec); // Check if Red's Pokemon is already in his bag
        //Ash.addPokemon(sec); //Ash is a filthy Thief and tries to steal Red's Pokemon



        Ash.ListPokemon();
        Red.ListPokemon();
        System.out.println(first.lk.getname());
        System.out.println(sec.lk.getname());

    }
}