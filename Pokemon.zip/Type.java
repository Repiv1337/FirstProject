package de.uni.hd.isw.bigfolder;

public enum Type {
    FIRE,
    WATER,
    Poisen;
}
