package de.uni.hd.isw.bigfolder;

public class Swap {
    Pokemon p1;
    Pokemon p2;

    Swap(Pokemon p1,Pokemon p2) {
        this.p1 = p1;
        this.p2=p2;
    }
    void execute(){
        int swap1 = 0;
        int swap2 = 0;
        while(swap1<p1.lk.pokemons.size()){
            if(p1.lk.pokemons.get(swap1).ID==p1.ID){

                break;
            }
            swap1++;
        }
        while(swap2<p2.lk.pokemons.size()){
            if(p2.lk.pokemons.get(swap2).ID==p2.ID){

                break;
            }
            swap2++;

        }
      Pokemon temp = new Pokemon(p1);

        ;//Die Variabel wird mit verändert obwohl die hier erzeugt wurde wtf?

        p1.setTrainer(p2.lk);
        p2.setTrainer(temp.lk);
        p1.lk.pokemons.set(swap1,p2);
        p2.lk.pokemons.set(swap2,p1);



    }
}
